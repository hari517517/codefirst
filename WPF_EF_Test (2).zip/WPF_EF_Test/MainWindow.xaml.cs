﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_EF_Test
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MyDBContext Context = null;
        public MainWindow()
        {
            InitializeComponent();
            Context = new MyDBContext();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            int empId = 1;
            //Inserting...
            //Context.Employees.Add(new AbcEmployee_172476 { EmpName = "Bharadwaj", DOJ = DateTime.Now.AddYears(-3) });
            //Context.SaveChanges();
            //MessageBox.Show("Record Added");
            //updating
            //int empId = 1;
            //string nName = "Preeti";
            //DateTime doj = DateTime.Now.AddYears(-5);

            //AbcEmployee_172476 emp = Context.Employees.SingleOrDefault(e1 => e1.AbcEmployeeID == empId);
            //emp.EmpName = nName;
            //emp.DOJ = doj;
            //Context.SaveChanges();
            //MessageBox.Show("Record updated");

            //AbcEmployee_172476 emp = Context.Employees.SingleOrDefault(e1 => e1.AbcEmployeeID == empId);
            //Context.Employees.Remove(emp);
            //Context.SaveChanges();
            //MessageBox.Show("1 record deleted");
            dgEmps.ItemsSource = Context.Employees.ToList();
        }
    }
}
