﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WPF_EF_Test
{
    class AbcEmployee_172476
    {
        [Key]
        public int AbcEmployeeID { get; set; } 
        public string EmpName { get; set; }
        public DateTime DOJ { get; set; }
    }
}
