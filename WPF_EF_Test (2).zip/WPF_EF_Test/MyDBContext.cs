﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_EF_Test
{

    class MyDBContext : DbContext
    {
        public DbSet<AbcEmployee_172476> Employees { get; set; }
    }
}
